| clue                             |   discriminative_score |
|:---------------------------------|-----------------------:|
| alias_bill_found                 |               3.27627  |
| delicate_knife_found             |               2.80097  |
| dog_silent                       |               2.60667  |
| horse_hidden_by_neighbor         |               2.49886  |
| tracks_to_rival_property         |               2.35725  |
| dog_familiarity_score            |               1.94984  |
| instrument_delicacy_score        |               1.90417  |
| death_consistent_with_horse_kick |               1.71168  |
| stable_boy_drugged               |               1.58394  |
| outsider_seen_near_stable        |               1.29675  |
| coat_deliberately_placed         |               1.1976   |
| horse_at_scene                   |               0.932304 |