| metric                     |    value |
|:---------------------------|---------:|
| planner_accuracy           | 0.902    |
| top2_accuracy              | 0.993333 |
| multiclass_log_loss        | 0.21011  |
| multiclass_brier_score     | 0.132119 |
| mean_prediction_confidence | 0.904269 |