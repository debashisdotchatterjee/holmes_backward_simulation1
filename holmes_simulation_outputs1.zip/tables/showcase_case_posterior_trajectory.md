|   step | clue                             |   outsider_gambler |   trainer |   rival_trainer |   unknown_intruder |
|-------:|:---------------------------------|-------------------:|----------:|----------------:|-------------------:|
|      1 | outsider_seen_near_stable        |        0.44043     |  0.304688 |     0.0966797   |        0.158203    |
|      2 | stable_boy_drugged               |        0.283327    |  0.594547 |     0.0746325   |        0.0474934   |
|      3 | dog_silent                       |        0.0460409   |  0.927498 |     0.0218301   |        0.00463063  |
|      4 | dog_familiarity_score            |        2.55338e-10 |  1        |     1.74865e-09 |        1.17156e-12 |
|      5 | delicate_knife_found             |        1.72138e-11 |  1        |     1.96477e-10 |        3.94907e-14 |
|      6 | instrument_delicacy_score        |        4.54419e-17 |  1        |     2.55336e-15 |        2.066e-21   |
|      7 | alias_bill_found                 |        1.62293e-18 |  1        |     2.1278e-16  |        2.45952e-23 |
|      8 | coat_deliberately_placed         |        4.95894e-19 |  1        |     1.21166e-16 |        4.7824e-24  |
|      9 | horse_at_scene                   |        3.19932e-19 |  1        |     8.72919e-17 |        2.51976e-24 |
|     10 | death_consistent_with_horse_kick |        6.69624e-20 |  1        |     3.14657e-17 |        2.63696e-25 |
|     11 | tracks_to_rival_property         |        1.67406e-19 |  1        |     1.04886e-17 |        6.88538e-25 |
|     12 | horse_hidden_by_neighbor         |        1.94094e-20 |  1        |     1.30727e-17 |        4.98941e-26 |